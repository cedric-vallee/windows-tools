---
name: Other requests
about: Request features or usage documents
title: ''
labels: ''
assignees: ''

---

**What command or commands**

<!-- Add a feature to LinkHints, Vomnibar or `scroll*`, or need a new command -->

**How should a feature do**

When a user has done such steps:

<!-- 1. Go to URL "..."
2. Select an ... element
3. Press a key like "..." -->

then Vimium C should do:

<!-- 1. Click on "..." -->

**Browser and OS**

- Browser name: 
- OS name: 

<!-- If you're using MS Edge, Chrome, or other Chromium-based browsers,
include the browser and OS version found at `chrome://version`.
Also include the Vimium C version found at `chrome://extensions`. -->

<!-- If you're using Firefox, report the Firefox and OS version found at `about:support`.
Also include the Vimium C version found at `about:addons`. -->
