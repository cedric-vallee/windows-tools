
export declare const MathParser: {
  evaluate (expr: string): number | Function
  clean (): void
  errormsg: string
}
